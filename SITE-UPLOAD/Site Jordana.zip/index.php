﻿


<!doctype html>
<html>
<head>
<link rel="stylesheet" media="(max-width: 640px)" href="css/Styleindex-mobile.css">
<link rel="stylesheet" media="(min-width: 640px)" href="css/Styleindex-desck.css">

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="cycle.js"></script>
<script type="text/javascript" src="funcoes.js"></script>
<script type="text/javascript" src="funcoes2.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<title>Página Jordana Brusa</title>
</head>

<body background="img/BG.gif">
<div id="site">

<?php 

 include "header.php";
 
 ?>




<div id="dados">
 <span id="dados-dois">WhatsApp:(51)9.8459.6917</span>
 <span id="dados-tres"><a href="https://www.facebook.com/pianopoa">www.facebook.com/pianopoa</a></span>
 <span id="dados-quatro"><a href="https://www.youtube.com/channel/UCh1K7DHlglexif0ll-jSN0g">Youtube</a></span>
 <span id="dados-cinco">E-mail:<br> jordanabrusa11@gmail.com</span>
 
 

</div>

<div id="fotos-um">
	<ul>
    
    	<li id="um"><img src="img/slide1.gif" width="" height="" alt=""/></li> 
     </ul>
</div>






<div id="linha">


</div>


<div id="box-um">

<div id="janelaFotos-um">


 
 
 <p>
 
"A Jordana foi o melhor acontecimento de 2017 e continua sendo! Uma pessoa querida, dedicada e cheia de paciência que pelas qualidades pessoais e profissionais me ajudou a resgatar o piano. Suas aulas são alegres e criativas nas quais além da técnica a pessoa entra na <a id="link-um" href="info.php"> música </a>e no que o compositor quis expressar através daquelas notas, daquele compasso e daquele ritmo! Recomendo essa guria, cheia de orgulho!!!!!"    



  
  </p>


 <p id="um">
 
  
 Dra. Luiza Hoefel, Psiquiatra

  
  </p>
 

</div>

<div id="texto-tres">

 <p>
 
"Por sua arte de tocar, técnica, sensibilidade e valor interpretativo, recomendo a professora de piano Jordana Brusa"
 </p>

<p>
 Poeta Mário Orcy

</p>
</div>

</div>

</div>

<div id="espaco">

</div>
</body>
</html>