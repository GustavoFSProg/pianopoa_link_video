

$(function(){
	
	$("div#fotos-um ul ").cycle({
		
		fx: 'fade',
		speed:'700',
		timeout:'6000',
		pager:'div#paginator'
		
		})
	})