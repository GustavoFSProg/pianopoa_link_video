﻿<!doctype html>
<html>
<head>
<link rel="stylesheet"  media="(max-width: 640px)" href="css/StyleFotos-mobile.css">
<link rel="stylesheet"  media="(min-width: 640px)" href="css/StyleFotos-desck.css">

<link rel="stylesheet"  href="shadowbox.css">

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="shadowbox.js"></script>
<script type="text/javascript">

Shadowbox.init();
</script>
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta charset="utf-8">
<title>Página Jordana Brusa</title>
</head>




<body background="img/BG.gif">
<div id="site">
<?php 

 include "header.php";
 
 ?>

<div id="nome">
<h1 id="title">Jordana Brusa</h1>
 <span id="aulas">Aulas Particulares de Piano em Domicílio</span>

</div>

<div id="linha">

</div>

<div id="box-geral">

<div id="img-um">
<a href="1.jpg" rel="shadowbox" width="200" height="200"><img src="1.jpg"  alt=""></a>
</div>


<div id="img-dois">
<a href="5.jpg" rel="shadowbox" width="200" height="200"><img src="5.jpg" width="" height="" alt=""></a>
</div>

<div id="img-tres">
<a href="2.jpg" rel="shadowbox" width="200" height="200"><img src="2.jpg" width="" height="" alt=""></a>
</div>


<div id="img-quatro">
<a href="3.jpg" rel="shadowbox" width="200" height="200"><img src="3.jpg"  alt=""></a>
</div>

</div>
</div>

<div id="espaco">
</div>
</body>
</html>
