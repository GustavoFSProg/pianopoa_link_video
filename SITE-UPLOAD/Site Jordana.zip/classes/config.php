<?php

  define("SERVIDOR", "pag_jordana.mysql.dbaas.com.br (186.202.152.123)");
  define("USUARIO", "pag_jordana");
  define("SENHA", "jogu33");
  define("BANCO", "pag_jordana");
  
  
?>