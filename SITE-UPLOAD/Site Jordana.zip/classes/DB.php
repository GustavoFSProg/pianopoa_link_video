<?php

	require_once "config.php";

	class DB{

		private static $db= null;
		private static $pdo;

		final function __construct(){

			try{

				self::getDB();

			}catch (Escepotion $ex){


				$ex->getMessage();
			}

		}


		static function getInstance(){


			if(self::$db == null){


				self::$db= new self();

			}

			return self::$db;
		}

		public function getDB(){

			if(self::$db == null){


				self::$pdo=$conn=new PDO('mysql:host=pag_jordana.mysql.dbaas.com.br;dbname=pag_jordana','pag_jordana','jogu33');

					
			}


			return self::$pdo;

		}

	}
?>