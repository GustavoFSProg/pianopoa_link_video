﻿<!doctype html>
<html>
<head>
<link href="loginusu.css" rel="stylesheet" type="text/css">
<meta charset="utf-8">
<title>Página Jordana Brusa</title>
<style type="text/css">


*{
	
 margin:0;  padding:0;	
}
 body
 {
	background:url(img/BG.gif);
	
	 text-align:center;
}

div#site{
			float:left;
			margin-left:155px;
			width:1000px;
			height:1300px;
			/*background:#79E195;*/
			
			}
			
				
						
			
 
	  
	  span#servico{
	  
	  float:left;
	  margin-left:300px;
	  margin-top:-650px;
	  font-family:Gabriola;
	  font-weight:bold;
	  color:#CE57EF;
	  font-size:44px;
	  
	  }
	  
	   span#cidade{
	  
	  float:left;
	  margin-left:240px;
	  margin-top:310px;
	  font-family:Gabriola;
	  font-weight:bold;
	  color:#CE57EF;
	  font-size:36px;
	  
	  }


 		
				
			div#site div#nome{
				float:left;
				width:1000px;
				height:200px;
				background:#CFC8F3;
				margin-left:-29px;
				margin-top:-255px;
				border:1px solid #A981EB;
				border-radius:5px;
				}


	
	div#site div#nome span#aulas{
		
		 float:left;
	  margin-left:235px;
	  margin-top:5px;
	  font-family:Gabriola;
	  font-weight:bold;
	  color:#CE57EF;
	  font-size:34px;
	
		}
		
		

  h1#title{
	  
	  float:left;
	  margin-left:345px;
	  margin-top:50px;
	  font-family:Gabriola;
	  font-weight:bold;
	  color:#CE57EF;
	  font-size:52px;
	  
	  } 
	  
	  
	  div#site div#menu{
				float:left;
				width:1000px;
				height:50px;
				background:#A981EB;
				border:1px solid #A981EB;
				border-radius:5px;
				margin-left:-30px;
				margin-top:210px;
				}
				
			div#site div#menu ul li{
				display:inline;
				font-family:Trebuchet;
				font-weight:bold;
				color:#6F3398;
				font-size:18px;
				background:#E1C9EA;
				padding:5px;
				border:1px solid #A062D0;
				height:26px;
				width:100px;
				}	
				
				div#site div#menu ul li#home{
					float:left;
					margin-left:60px;
					margin-top:5px;
					text-align:center;
					width:8%;
					}
				
				
				div#site div#menu ul li#home a{
					float:left;
					margin-top:5px;
				}
				
				
				
				div#site div#menu ul li#info{
					float:left;
					margin-left:70px;
					margin-top:5px;
					text-align:center;
					width:15%;
					}
				
				
				div#site div#menu ul li#info a{
					float:left;
					margin-top:5px;
				}
				
				
				div#site div#menu ul li#fotos{
					float:left;
					margin-left:70px;
					margin-top:5px;
					text-align:center;
					width:7%;
					}
				
				
				div#site div#menu ul li#fotos a{
					float:left;
					margin-top:5px;
				}
				
				
				div#site div#menu ul li:hover{
					color:#F7F7F7;	
				background:#3C6EB0;
				
					}
				
				div#site div#menu ul li a{
				text-decoration:none;
					
				}
			div#site div#menu ul li a:link{
				color:#8B38D1;	
				}

div#site div#menu ul li a:hover{
				color:#F7F7F7;	
				background:#3C6EB0;
				}
				
				
				div#site div#menu ul#admin li#adm{
				display:block;
				font-family:Gabriola;
				color:#6F3398;
				font-size:22px;
				background:#E1C9EA;
				padding:5px;
				border:1px solid #A062D0;
				float:left;
				margin-top:550px;
				width:168px;
				position:absolute;
				}	 
				
				div#site div#menu ul#admin li#adm:hover{
					color:#F7F7F7;	
				background:#3C6EB0;
				
					}
				
				div#site div#menu ul#admin li#adm a{
				text-decoration:none;
					
				}
			div#site div#menu ul#admin li#adm a:link{
				color:#8B38D1;	
				}

div#site div#menu ul#admin li#adm a:hover{
				color:#F7F7F7;	
				background:#3C6EB0;
				}


div#site div#login{
	float:left;
	width:350px;
	height:280px;
	background:#F8F8F8;
	margin-top:15%;
	margin-left:32%;
	border:1px solid #969696;
	}
	div#site div#login span.title{
	float:left;
	width:330px;
	height:25px;
	background:#53ACD6;
	margin-top:5px;
	margin-left:5px;
	font-family:tahoma;
	font-size:18px;
	color:#F7F7F7;
	text-align:left;
	padding:5px;	
		}
		
div#site div#login span.aviso{
		float:left;
	width:337px;
	height:35px;
	background:#F7F49C;
	border:1px solid #EFE129;
margin-top:5px;
	margin-left:5px;
	font-family:Lucida;
	font-size:16px;
	color:#6B6B6B;
	
	}
	
	
div#site 	div#login label#email{
		float:left;
		margin-top:10px;
		margin-left:0px;
		
		}
	div#site div#login label#email span{
		font-family:Lucida;
		color:#828282;
		font-size:16px;
		text-align:left;
		width:300px;
		height:20px;
		margin-left:10px;
		margin-top:10px;
		float:left;
		}
	
	div#site div#login label#senha span{
		font-family:Lucida;
		color:#828282;
		font-size:16px;
		text-align:left;
		width:300px;
		height:20px;
		margin-left:10px;
		margin-top:10px;
		float:left;
		
		}
		
	div#site 	div#login label#email input#mail{
			font-family:Lucida;
		color:#828282;
		font-size:16px;
		background:#E7E7E7;
		border:1px solid #D7D7D7;
		border-radius:4px;
		width:335px;
		height:25px;
		margin-top:1px;	
			}
	
	
	div#site div#login label#senha{
		float:left;
		margin-top:10px;
		margin-left:0px;
		
		}
	
	div#site div#login label#senha input#pass{
			font-family:Lucida;
		color:#828282;
		font-size:16px;
		background:#E7E7E7;
		border:1px solid #D7D7D7;
		border-radius:4px;
		width:335px;
		height:25px;
		margin-top:1px;	
			}
	
	
div#site	div#login input#Logar{
		color:#F5F5F5;
		font-size:16px;
		background:#1581B5;
		border:1px solid #D7D7D7;
		border-radius:4px;
		width:70px;
		height:35px;
		margin-top:1px;	
		float:left;
		margin-top:15px;
		margin-left:275px;
		
		
		
		}
	
	
	
	
	
	
div#site	p#aviso{
	float:left;
	padding:6px;
	background:#ffffc4;
	border: 1px solid #ffff15;
	font-family:Tahoma;
	color:#666;
	font-size:16px;
	width:99%;
	margin-bottom:5px;
	text-align:center;
	}
</style>
</head>

<body>

<div id="site">
<div id="menu">
 <ul>
 	<li id="home"><a href="index.php">HOME</a></li>
    <li id="info"><a href="info.php">INFORMAÇÕES</a></li>
    
     <li id="fotos"><a href="fotos.php">FOTOS</a></li>
   
    </ul>
    
    
</div>

<div id="nome">
<h1 id="title">Jordana Brusa</h1>
 <span id="aulas">Aulas Particulares de Piano em Domicílio</span>


</div>

<div id="login">
<span class="title">Efetuar Login</span>
<span class="aviso">Para voce ter acesso ao painel, você deve ter um acesso confirmado com o administrador do site</span>

<form action="ValidaLogin.php" method="post">
<label id="email"><span>Email</span> <input type="text" name="email" id="mail"></label>
<label id="senha"><span>Senha </span><input type="password" name="senha" id="pass"></label>

<input type="hidden" value="acao" name="entrar">

<input type="submit" value="Logar" id="Logar">
</form>

</div>
</div>
</body>
</html>