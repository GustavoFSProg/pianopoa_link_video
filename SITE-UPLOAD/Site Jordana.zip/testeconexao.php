﻿<?php
$conn=new PDO('mysql:host=pag_jordana.mysql.dbaas.com.br;dbname=pag_jordanaB','pag_jordana','jogu33');

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body>
</body>
</html>