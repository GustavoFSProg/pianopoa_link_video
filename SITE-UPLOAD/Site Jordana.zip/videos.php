﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body background="img/BG.gif">
<div id="site">

<?php

include "header.php";
?>

</div>
</body>
</html>