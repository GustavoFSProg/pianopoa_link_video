﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body background="img/BG.gif">
<center><h1>Página não permitida </h1><Br><br><br>

<a href="index.php"><h1>Voltar</h1></a>

</center>
</body>
</html>