﻿<!doctype html>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css">
<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body background="BG.gif">
<center><h1>Erro 404 </h1></center>
</body>
</html>