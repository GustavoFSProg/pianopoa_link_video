﻿   

<!doctype html>
<html>
<head>

<link rel="stylesheet" media="(max-width: 640px)" href="css/StyleInfo-mobile.css">
<link rel="stylesheet" media="(min-width: 640px)" href="css/StyleInfo-desck.css">

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<title>Página Jordana Brusa</title>
</head>

<body background="img/BG.gif">
<div id="site">

<div id="menu">
 <ul>
 	<li id="home"><a href="index.php">HOME</a></li>
    <li id="info"><a href="info.php">INFORMAÇÕES</a></li>
    
     <li id="fotos"><a href="fotos.php">FOTOS</a></li>
   
    </ul>
    
    
</div>

<div id="nome">
<h1 id="title">Jordana Brusa</h1>
 <span id="aulas">Aulas Particulares de Piano em Domicílio</span>


</div>
<div id="nome">
<h1 id="title">Jordana Brusa</h1>
 <span id="aulas">Aulas Particulares de Piano em Domicílio</span>

</div>


<span id="servico">Aulas Particulares de Piano em Domicílio</span>

<span id="cidade">Porto Alegre  e Serra Gaúcha - RS-Brasil</span>

<div class="linha">

</div>

<div id="janela1">
 <span id="repertorio">Repertório</span>
 
   <ul>
   <li class="erudito">Erudito</li>
   	<li class="avancado">Avançado e Iniciante</li>
    </ul>
    
    <ul>
    <li class="popular">Popular</li>
    <li class="tangos">Tangos, MPB, Rock</li>
   
    </ul>
</div>

<div id="janela2">
<li id="teoria"> Teoria</li>


<li id="harmonia">Harmonia</li>

<li id="ritmo">Ritmo</li>

<li id="impro">Improvisação</li>
</div>

<div id="frases">
<span id="dados-um">Jordana Brusa, Bacharel em Música UFRGS 2008 com Formação
 Continuada em Barcelona, Espanha.</span>
</div>

<div id="frases-dois">

<span id="dados-dois">Há mais de 10 anos lecionando e atuando como Pianista Colaboradora.</span>

</div>
</div>


<div id="footer">
 <p>
  
 </p>
 </div>
</body>
</html>
