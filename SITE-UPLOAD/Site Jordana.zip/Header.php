﻿<!doctype html>
<html>
<head>
<link rel="stylesheet" media="(max-width: 640px)" href="css/Styleindex-mobile.css">
<link rel="stylesheet" media="(min-width: 640px)" href="css/Styleindex-desck.css">


<meta charset="utf-8">
<title>Documento sem título</title>
</head>

<body>

<div id="menu">
 <ul>
 	<li id="home"><a href="index.php">HOME</a></li>
    <li id="info"><a href="info.php">INFORMAÇÕES</a></li>
    
     <li id="fotos"><a href="fotos.php">FOTOS</a></li>
   
    </ul>
    
    
</div>

<div id="nome">
<h1 id="title">Jordana Brusa</h1>
 <span id="aulas">Aulas Particulares de Piano em Domicílio</span>


</div>
</body>
</html>